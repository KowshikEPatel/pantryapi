

export default function Topbar(){

    return <>
        <div className="container">
            <div className="row">
                <div className="col-sm-3">
                    this is col
                </div>
                <div className="col-sm-3">
                    this is col
                </div>
                <div className="col-sm-3">
                    this is col
                </div>
            </div>
        </div>
    </>
}